#!/usr/bin/env python
# -*- coding:utf-8 -*-
'''
@Author  : xiaotudou
@time: 2019/07/17 8:26
@File    : __init__.py.py 
'''
import pymysql
pymysql.install_as_MySQLdb()